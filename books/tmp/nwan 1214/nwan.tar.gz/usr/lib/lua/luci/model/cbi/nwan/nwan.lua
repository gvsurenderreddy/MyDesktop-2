require("luci.tools.webadmin")

m = Map("nwan", "N-WAN","N-WAN allows for the use of multiple uplinks for load balancing and failover.")



s = m:section(TypedSection, "route", "SETTING PAGE","setting n-wan routes.")
s.addremove = flash


enable = s:option(ListValue, "enable", "N_WAN ON OR OFF")
enable :value("1", "ON")
enable :value("0", "OFF")

enable.default = "1"
enable.optional = flash
enable.rmempty = flash

ping_ck = s:option(ListValue, "ping_ck", "ON_LINE CHECK ON OR OFF")
ping_ck :value("1", "ON")
ping_ck :value("0", "OFF")
ping_ck.default = "0"
ping_ck.optional = ture
ping_ck.rmempty = ture

assingout = s:option(ListValue, "assingout", "ASSIGN OUT ON OR OFF")
assingout :value("1", "ON")
assingout :value("0", "OFF")
assingout.default = "0"
assingout.optional = ture
assingout.rmempty = ture

dl_route_table = s:option(ListValue, "dl_route_table", "AUTO DOWNLOAD ROUTE TABLE")
dl_route_table :value("1", "ON")
dl_route_table :value("0", "OFF")
dl_route_table.default = "0"
dl_route_table.optional = ture
dl_route_table.rmempty = ture




debug = s:option(ListValue, "debug", "DEBUG  LOG_RECORD")
debug :value("1", "OFF")
debug :value("5", "ON")
debug.default = "0"
debug.optional = ture
debug.rmempty = ture

sleeptime = s:option(Value, "sleeptime", "PING WAIT TIME / MIN")
sleeptime.optional = ture
sleeptime.rmempty = ture

testip = s:option(Value, "testip", "INTETNET TEST IP")
testip.optional = ture
testip.rmempty = ture




s = m:section(TypedSection, "interface", "WAN Interfaces")
s.template = "cbi/tblsection"
s.addremove = true


name = s:option(ListValue, "name", "isp name")
name:value("mobile", "mobile")
name:value("other", "other")
name:value("telecom", "telecom")
name:value("unicom", "unicom")
name.default = "telecom"
name.optional = ture
name.rmempty = ture

route = s:option(ListValue, "route", "wan route method")
route:value("intelligent_routes", "intelligent routes")
route:value("balance", "balanc")
route.default = "balance"
route.optional = ture
route.rmempty = ture


weight = s:option(ListValue, "weight", "Load Balancer weight")
weight:value("10", "10")
weight:value("9", "9")
weight:value("8", "8")
weight:value("7", "7")
weight:value("6", "6")
weight:value("5", "5")
weight:value("4", "4")
weight:value("3", "3")
weight:value("2", "2")
weight:value("1", "1")
weight.default = "1"
weight.optional = flash
weight.rmempty = ture

uptime = s:option(DummyValue, "uptime", "wan online time")
uptime.optional = flash
uptime.rmempty = flash

s = m:section(TypedSection, "mwanfw", "N-WAN ASSIGN OUT Rules",	"Configure rules for directing outbound traffic through specified WAN Uplinks.")
s.template = "cbi/tblsection"
s.anonymous = true
s.addremove = true

src = s:option(Value, "src", "Source Address")
src.rmempty = true
src:value("", translate("all"))
luci.tools.webadmin.cbi_add_knownips(src)

dst = s:option(Value, "dst", "Destination Address")
dst.rmempty = true
dst:value("", translate("all"))
luci.tools.webadmin.cbi_add_knownips(dst)

proto = s:option(Value, "proto", "Protocol")
proto:value("", translate("all"))
proto:value("tcp", "TCP")
proto:value("udp", "UDP")
proto:value("icmp", "ICMP")
proto.rmempty = true

ports = s:option(Value, "ports", "Ports")
ports.rmempty = true
ports:value("", translate("all", translate("all")))

wanrule = s:option(Value, "wanrule", "WAN Uplink")
luci.tools.webadmin.cbi_add_networks(wanrule)
wanrule:value("wan", translate("wan"))
wanrule.optional = false
wanrule.rmempty = false

return m
