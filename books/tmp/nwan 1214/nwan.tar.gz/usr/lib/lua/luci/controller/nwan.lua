module("luci.controller.nwan", package.seeall)

function index()
    local fs = luci.fs or nixio.fs
    if not fs.access("/etc/config/nwan") then
		return
	end
	
	local page = entry({"admin", "network", "nwan"}, cbi("nwan/nwan"), "N-WAN")
	page.i18n = "nwan"
	page.dependent = true
	
        local page = entry({"mini", "network", "nwan"}, cbi("nwan/nwanmini", {autoapply=true}), "N-WAN")
         	page.i18n = "nwan"
         page.dependent = true


end
