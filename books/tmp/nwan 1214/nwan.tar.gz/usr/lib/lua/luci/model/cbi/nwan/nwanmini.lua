require("luci.tools.webadmin")


m = Map("nwan", "N-WAN",
"N-WAN allows for the use of multiple uplinks for load balancing and failover.")



s = m:section(TypedSection, "route", "SETTING PAGE",
	"setting n-wan routes.")
s.addremove = flash


enable = s:option(ListValue, "enable", "N_WAN ON OR OFF")
enable :value("1", "ON")
enable :value("0", "OFF")

enable.default = "1"
enable.optional = flash
enable.rmempty = flash

return m


