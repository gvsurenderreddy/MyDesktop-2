/////////////////////////////////////////////////////////////////////////////////
//
//  Total Updater v0.8.6.9 (Stable)
//  Total Commander & plugin updater utility.
//
//  Copyright (C) 2012-2015 Bluestar
//  - dev.bluestar [@] hotmail.com -
//
//
//  License to copy, use, and redistribute this software for any purpose is
//  granted provided that this notice may not be removed from this document.
//
//  This free software is distributed in the hope that it will be useful, but
//  WITHOUT ANY WARRANTY. In no event will the author or any other contributor
//  be held liable for any damages arising from the use of this software.
//
/////////////////////////////////////////////////////////////////////////////////


01. About
_________

Total Updater is a small tool that helps you to keep your Total Commander &
its plugins up-to-date. If you are using dozens of plugins for TC / always wants
to be sure that you are using the latest version of our beloved filemanager,
then this software is definitely for you.


02. Prerequisites
_________________

It is recommended to unpack the official SSL package (libeay32 & ssleay32.dll)
to the utility's folder to be able to download from sites using https connection.

You can download the package from the following site: http://indy.fulgan.com/SSL/
The latest version at the time of writing is: "openssl-1.0.1e-i386-win32.zip"


02. Main Features
_________________

 - Built-in multilingual support (Chinese Simplified, Czech, Danish, Dutch,
   English, French, German, Hungarian, Italian, Lithuanian, Polish, Russian,
   Slovak, Spanish, Swedish, Ukrainian)
 - List all the installed plugins, addons, utilities & search their latest update
 - Install the downloaded packages automatically (updating of the plugins)
 - Advanced version detection routine: detect version based on history/readme/
   whatsnew file(s) even if embedded verinfo field doesn't exists 
 - Advanced version compare routine: compare the files based on local & online
   version and date (if update found), to minimize the number of false alarms
 - Download selected / marked plugins quickly & easily
   (just double click on an item in the Download dialog to open the url in case a
   download fails for any reason [ssl connection, redirections, etc])
 - Download files through SSL connection (in case the server forces it):
   just download the latest zip from the following site & unzip the files
   "libeay32.dll" and "ssleay32.dll" to Total Updater's dir:
   http://indy.fulgan.com/SSL/
 - Internal Plugin Database (IPD), which makes available for the utility to
   properly detect the plugin packages based on filename 
 - You can add custom new items to UserDB (just search their ID on totalcmd.net,
   and they're going to override the matching original IPD [database] entry)
 - Simply press right-click in the plugin list, and click on "Marked items" ->
   "Confirm updatable item(s) as latest" to avoid false alarms, if there are any
 - Display additional info of every plugin by double-clicking on it
   (in English / Russian language - based on system's current locale) 
 - Infobox feature - display verinfo & icon of each plugin
   (right click on the list & choose Show Infobox, or press Ctrl + Q) 
 - Exclude from list option (file / directory) 
 - Full Unicode support 
 - ... and much more!


03. Compatibility
_________________

Basically any Total Commander version (heavily tested under 7.57a & 8.01).
Required operating system: Microsoft Windows XP or newer.


04. Translation
_______________

If you'd like to translate Total Updater to your native language, you can
download the latest English language file from the following link:

 - http://bluesoft.hu/system/download/dl.php?id=7

Please check the homepage or the ghisler.ch forum for more instructions.


05. Contact
___________

 - Official support thread (bugreports, feature requests, etc):
   http://www.ghisler.ch/board/viewtopic.php?t=36309

 - You can also find the plugin on TOTALCMD.net:
   http://www.totalcmd.net/plugring/totalupdater.html

 - Homepage of the plugin (hotkeys, instructions):
   http://totalupdater.bluesoft.hu

 - Contact me by e-mail:
   dev.bluestar [@] hotmail.com


06. History
___________

See the "whatsnew.txt" file.


07. Currently available hotkeys
_______________________________

- F2                   : Refresh local version information of the selected items
- F5 / Ctrl + R        : Refresh the whole plugin list & reload the database
- Alt + Enter          : Open the addon information dialog (double-click on item)
- Space                : Mark (tick) the selected item
- Ctrl + S             : Search / filter the list of plugins
- Ctrl + C             : Copy the selected items information to the clipboard
- Ctrl + Shift + C     : Copy the selected items information to the clipboard
                         (debug mode including CRC32 values)
- Ctrl + G             : Generate checksum entries for the selected items
                         in ini-like structure & copy it to clipboard
- Ctrl + D             : Download the currently selected file(s)
- Ctrl + I             : Download & install the currently selected file(s)
                         (you can use it in the Download dialog too, if the
			  downloading of the files has already been finished)
- Ctrl + Shift + D     : Download the currently selected file(s) using IDM
                         (if Internet Download Manager is installed on the PC)
- Ctrl + Shift + W     : Visit the current item's website if it exists
- Ctrl + Shift + A     : Visit author website of the current item if it exists
- Ctrl + Num+          : Mark (tick) all the selected items in the list
- Ctrl + Num-          : Unmark (untick) all the selected items in the list
- Ctrl + Up            : Jump to the currently selected items by opening new tab
                         (redirected to Total Commander)
- Ctrl + PageDown      : Jump to the currently selected items
                         (redirected to Total Commander)
- Ctrl + Z             : Show the Internal Plugin Database / add item to UserDB
                         (in case the current one doesn't exists in the IPD yet)
- Ctrl + X             : Exclude the selected file(s) from the list
- Ctrl + Q             : Show / hide the Infobox panel
- -> (Right arrow key) : Jump to the next updatable item in the list (if exists)
- <- (Left arrow key)  : Jump to the previous updatable item (if exists)


07. Currently available command line (cmd) parameters
_____________________________________________________

/autostart             : automatically start the search of updates right after
                         the utility starts
/autostartdl           : automatically start the search of updates and download
                         the found packages as well
/autostartinstall      : automatically start the search of updates, then
                         download the found packages and install them as well
/strictver             : do not treat latest compile / modification date
                         as a version number (NOTE: some of your plugins without
			 embedded version information will probably be excluded
			 from the list of the plugins in case you run TU
			 using this switch!)
/notc                  : do not try to detect & update the current TC instance
/safe                  : run Total Updater in a special safe mode if you encoun-
                         ter any problem in normal mode (not recommended for
			 daily usage)
			 DISABLED FEATURES IN SAFE MODE:
			 - 3rd party tool detection (utilities)
			 - intelligent version detection (for plugins)
			 - installing updates
			 ENABLED FEATURES IN SAFE MODE:
			 - refresh GUI while initializing the list of plugins
			   [PrcMsgOnLoad=True]


08. Configuration parameters
____________________________

There are some special option / key that can't be set from inside Total Updater,
but they can be very handy in various situations. Below you can see the list
of the available keys you can add to "TotalUpdater.ini" by editing it in notepad.


[GUI]
PrcMsgOnLoad=True                                               (default : False)
   Set this to "True" to refresh the list of the plugins while still loading them
             (not recommended to change, it may cause slower refresh of the list)

AllowResize=False                                               (default : True )
                       Set this to "False" to disable resizing of the main window

JumpToFirstUpd=False                                            (default : True )
          If set to "False", TU will not jump to the first updatable item after a
                                successful search in case any update can be found

ScrollOnUpdCheck=False                                          (default : True )
         Set this to "False" to disable the scrolling while searching for updates

AlwaysSavePos=True                                              (default : False)
            Set this to "True" to always save the latest window coordinates of TU
	 instead only when Ctrl is pressed & hold down when clicking on Close [X]

ShowMenuShortcuts=False                                         (default : True )
              Set this to "False" to hide all the popup menu shortcuts in the app

ShowPlugIcons=False                                             (default : True )
     Set this key to "False" to disable showing embedded icons of the plugins and
                                        addons when viewing their data in Infobox


[Plugins]
SecondaryPlgDir=c:\path\to\your\tc\addons                       (default :  -   )
 You can set any folder in which your additional (installed) plugins can be found

ForceSecondary=True                                             (default : False)
         Set this to "True" to only load the plugins inside the "SecondaryPlgDir"

ForceUseOfFN=True                                               (default : False)
        Set this to "True" to see the plugins filename (without extension) in the
  list instead of their real online package name (if "OnlineNameCorr" is enabled)
                                                   or their corrected ProductName

OnlineNameCorr=False                                            (default : True )
                        Set this to "False" to disable the online name correction
             (by default the utility automatically tries to retrieve the matching
	                                             online name of the packages)

VerCorrOnDateMatch=False                                        (default : True )
     Set this to "False" to disable the automatic correction of the local version
        of the plugins in case their date matches the one of their online package
(by default these values are automatically saved under [OverridePlugVer] section)

ChecksumDBstate=0                                               (default :   2  )
      You can set this key to 0/1/2 to disable/enable/enable (force using of) the
                    additional checksum database (not recommended to turn it off)

TreatDateAsVer=False                                            (default : True )
       You can set this key to "False" to exclude items from the list without any
           real version information but PE TimeDateStamp / last modification date
           
 NOTE: This feature has been introduced because most of the plugins unfortunately
            doesn't contain an accurate version information inside their PE file,
	  thus it is often needed to check their compile date / last modification
                      date to be able to get some more info about them, so we can
		                                   compare them to the online one

UpdateDateCheck=False                                           (default : True )
                You can set this to "False" to disable the additional comparement
        based on the local PE / file modification date & online modification date
	                                         in case a newer version is found

PubDateDiffCorr=0                                               (default :    1 )
         This key is used for the UpdateDateCheck function - many times an update
        is not released on the same they it is built (PEDate), so the server date
          is going to be one daynewer than the local one, thus many plugins would
           show up as updatable in the list. With this key we set a threshold, so
                  by default 1 day difference would mean we are talking about the
                                  same version of the plugin that we have locally

ExcludeInstFiles=txt,lst,ini,eng,en,deu,de,...,etc              (default :  -   )
         You can set any filetypes (or filenames) which you would like to exclude
	                              when installing new versions of the plugins


[Configuration]
TempDirectory=c:\path\to\extract				(default : - )
	This value is automatically set to the user's default download directory,
		        falls back to using %TEMP% if not found / doesn't exists.
     IMPORTANT: in case the automatic installation for the plugins doesn't works,
              please make sure that the defined directory exists & can be written
                                        by the utility, and fix it if its needed.

ProxyEnabled=True                                               (default : False)
          Set this value to "True" to make the application use your active proxy.
                 You need to set up the details of the connection in order for it
                                            to make properly - see the keys below


ProxyAddress=127.0.0.1                                          (default :  -   )
                                         Type in the address of your proxy server

ProxyPort=7070                                                  (default :  -   )
                                            Type in the port of your proxy server

ProxyUsername=abc                                               (default :  -   )
                                 The username used to connect to the proxy server
                          (leave it blank if none is used / no validation needed)

ProxyPassword=12345                                             (default :  -   )
                                 The password used to connect to the proxy server
                          (leave it blank if none is used / no validation needed)

ProxyType=1                                                     (default :   0  )
                                                   Set the type of the used proxy
 "0" - HTTP
 "1" - SOCKS4
 "2" - SOCKS5

DatabaseEnabled=False                                           (default : True )
                You can set this key to "False" in case you'd like to disable the
	        Internal Plugin Database (IPD), which helps the utility to detect
	              the plugins matching online package based on their filename
                                                 (not recommended to turn it off)

ForceUseExtDB=True                                              (default : False)
                                     You can set this key to "True" to always use
                    the external "database.dat" file as DB regardless of its date
  (by default the external one is not loaded when its older than the internal DB)

UseIniInTCDir=True                                              (default : False)
Set this to "True" to place the configuration file of utility beside "wincmd.ini"
                instead of the directory where "TotalUpdater.exe" is running from

SearchEngine=http://google.com/search?q=%s                      (default : <--  )
 You can set it to any string ("%s" will be replaced to the actual search string)
                      to change the default Google search engine to anything else

PreInstallAction=1                                              (default :    0 )
  "0" - do nothing (option disabled)
  "1" - create a backup of all the files being overwritten
        in the directory of the current plugin
  "2" - create a backup of only the text [non-binary] files being overwritten
        in the directory of the current plugin (e.g. config, language files etc)

PostInstallAction=1                                             (default :    0 )
  Sum of the following values:
  "0" - do nothing (option disabled)
  "1" - delete the actual package after successful installation
  "2" - delete the "pluginst.inf" file from the plugin installation path
  "4" - delete the x64 version of the currently installed plugin

HttpTimeOut=10000                                               (default : 7000 )
                 You can set this key to configure the amount of time to wait for
                                     the server response before reporting timeout


[Total Commander]
DownloadPackage=1                                               (default :    0 )
  You can set this key to "1" or "2" to set the default Total Commander installer
                                    to be downloaded from the official site of TC
  "0" or "3264" or "3286" - download the default unified installer (x86+x64)
  "1" or "32" or "86"     - download the x86-only package
  "2" or "64"             - download the x64-only package

DevCompareMethod=True                                           (default : False)
                      You can set this key to "True" in case you'd like to to use
    the old TC compare method (PB > B) [e.g. in case you are a beta tester of TC]

ExcludeInstFiles=txt,lst,ini,eng,en,deu,de,...,etc              (default :  -   )
         You can set any filetypes (or filenames) which you would like to exclude
	                              when installing new versions of the plugins


[OverridePlugVer]
You can find all the plugins marked as latest inside this section (e.g. when the
user choose right click -> "Marked Items" -> "Confirm updatable items as latest")

The structure is the following:
PATH=CRC32(decimal)|version

e.g.:
%COMMANDER_PATH%\plugins\wcx\SomePlugin\filename.wfx=3718047628|1.2.4
 

09. Thanks
__________

To the great Total Commander (ghisler.ch) community for their ideas, bugreports
and contributions. Special thanks goes to Myone (alpha & beta testing, ideas),
and to all of the translators:

 - Chinese    : FeiXJ
 - Czech      : jvh
 - Danish     : petermad
 - Dutch      : Jaap Kramer
 - French     : TieFighter
 - German     : Gerby
 - Italian    : Luciano & Massimo Mula
 - Lithuanian : Dalius Gu�auskas (Tichij)
 - Polish     : Maciej Bojakowski
 - Portuguese : Dick Spade
 - Nederlands : J. Kramer
 - Slovak     : umbra
 - Slovenian  : Jadran Rudec
 - Spanish    : Patxiku
 - Swedish    : Trast
 - Korean     : cmlee
 - Russian    : Avada, Dmitriy Vasilyev
 - Ukrainian  : Pavlo Dergunov (LonerD)

Exceptional thanks to Christian Ghisler for creating Total Commander.
Special thanks to the staff of totalcmd.net, especially to Flint for his
server-side scripts & lots of help.

... and last, but not least thank you for downloading & using this utility.


10. Copyright notices
_____________________

- Portions of this software are Copyright (c) 1993 - 2003, Chad Z. Hower (Kudzu)
  and the Indy Pit Crew - http://www.IndyProject.org
- RAR Component Copyright (c) by Philippe Wechsler
  http://www.PhilippeWechsler.ch
- UnZIP library Copyright (c) 1998 - 2009 Conifer Software - All rights reserved
  (distributed under MPL 1.1 license)


11. WavPack license
___________________

               Copyright (c) 1998 - 2009 Conifer Software
                          All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of Conifer Software nor the names of its contributors
      may be used to endorse or promote products derived from this software
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.



Copyright (C) 2011-2015 Bluestar.